using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GameSpace.Models
{
    [Table("EVoucherToken")]
    public class EVoucherToken
    {
        [Key]
        [Column("TokenID")]
        public int TokenID { get; set; }

        [Required]
        [Column("EVoucherID")]
        public int EVoucherID { get; set; }

        [Required]
        [StringLength(64)]
        public string Token { get; set; } = string.Empty;

        [Required]
        public DateTime ExpiresAt { get; set; } = DateTime.UtcNow.AddMinutes(5);

        [Required]
        public bool IsRevoked { get; set; } = false;

        // 導航屬性
        [ForeignKey("EVoucherID")]
        public virtual EVoucher EVoucher { get; set; } = null!;
    }
}